﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Threading;

namespace QRRestaurantPrintAgent.PrintService
{
    public static class Printer
    {

        private delegate void PrintDelegate(FlowDocument document, string description, Action<bool> callback);
        public static void Print(Dispatcher dispatcher, FlowDocument document, string description, Action<bool> callback)
        {
            dispatcher.BeginInvoke(new PrintDelegate((_document, _description, _callback) =>
                {
                    _callback(Print(_document, _description));
                }), DispatcherPriority.ApplicationIdle, document, description, callback);

        }


        public static bool Print(FlowDocument document, string description)
        {
            try
            {
                new PrintDialog().PrintDocument(((IDocumentPaginatorSource)document).DocumentPaginator, description);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}