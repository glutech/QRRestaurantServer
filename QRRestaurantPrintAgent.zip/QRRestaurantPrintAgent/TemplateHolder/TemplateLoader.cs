﻿using System;
using System.Reflection;
using System.Windows.Documents;
using System.Windows.Markup;
using System.Linq;
using System.Windows;
using System.Windows.Threading;

namespace QRRestaurantPrintAgent.TemplateHolder
{
    public static class TemplateLoader
    {

        public static FlowDocument LoadAndRenderAsFlowDocument(string name, dynamic data)
        {
            Template.ATemplateEntity entity;
            if (FindTemplateEntity(name, out entity))
            {
                try
                {
                    return entity.BindingData(entity.LoadAsFlowDocument(), data == null ? entity.TestData : data);
                }
                catch (Exception e)
                {
                    throw new TemplateLoaderException("Template parse error: " + name, e);
                }
            }
            else
            {
                throw new TemplateLoaderException("Template not found: " + name);
            }
        }

        private delegate void LoadAndRenderAsFlowDocumentOnDispatcherDelegate(string name, dynamic data, Action<FlowDocument> callback);
        public static void LoadAndRenderAsFlowDocumentOnDispatcher(Dispatcher dispatcher, string name, dynamic data, Action<FlowDocument> callback)
        {
            dispatcher.BeginInvoke(new LoadAndRenderAsFlowDocumentOnDispatcherDelegate((_name, _data, _callback) =>
                {
                    var r = LoadAndRenderAsFlowDocument(_name, _data);
                    _callback(r);
                }), name, data, callback);
        }

        private static bool FindTemplateEntity(string name, out Template.ATemplateEntity outTypeInstance)
        {
            // 查找合法模板实体类，必须满足：
            // 1. 符合 class Template.{__NAME__}Entity : Template.ATemplateEntity 声明
            // 2. 包含无参公共构造
            var type = Type.GetType("QRRestaurantPrintAgent.TemplateHolder.Template." + "Demo" + "_Entity");
            if (
                type != null
                &&
                type.IsClass && !type.IsAbstract && !type.IsGenericType
                &&
                type.IsSubclassOf(typeof(Template.ATemplateEntity))
                )
            {
                foreach (var method in type.GetConstructors())
                {
                    if (method.GetParameters().Length == 0)
                    {
                        outTypeInstance = (Template.ATemplateEntity)Activator.CreateInstance(type);
                        return true;
                    }
                }
            }
            outTypeInstance = null;
            return false;
        }

    }

}