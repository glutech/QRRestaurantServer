﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Documents;

namespace QRRestaurantPrintAgent.TemplateHolder.Template
{
    internal class Demo_Entity : ATemplateEntity
    {
        public override string Path
        {
            get { return "Template/Demo_TPL.xaml"; }
        }

        public override object TestData
        {
            get
            {
                return new
                {
                    RestaurantName = "南亚风情第一城【欢乐岛】",
                    BoardName = "28号桌",
                    DinersCount = "1",
                    OrderNo = "74916",
                    DishList = new object[] {
                    new {
                        DishName = "欢乐牛扒（标准：五成熟）",
                        DishPrice = "58.00",
                        DishCount = "1"
                    },
                    new {
                        DishName = "欢乐牛扒2222（标准：五成熟）",
                        DishPrice = "58.00",
                        DishCount = "1"
                    }
                },
                    AggregateAmount = "58.00",
                    PaidAmount = "58.00",
                    OrderTime = "2014-1-13 12:32:13",
                    CashierName = "杨晓梅",
                    RestaurantPhone = "0871-64601199",
                    RestaurantAddress = "昆明市滇池路南亚风情第一城A1座三楼"
                };
            }
        }

        protected override void CustomRender(System.Windows.Documents.FlowDocument document,dynamic data)
        {
            var group = document.FindName("DishList") as TableRowGroup;
            var type = data.GetType();
            foreach (var item in data.DishList)
            {
                var row = new TableRow();
                var cellDishName = new TableCell(new Paragraph(new Run(item.DishName)));
                cellDishName.ColumnSpan = 7;
                row.Cells.Add(cellDishName);

                var cellDishPrice = new TableCell(new Paragraph(new Run("￥" + item.DishPrice)));
                cellDishPrice.ColumnSpan = 3;
                row.Cells.Add(cellDishPrice);

                var cellDishCount = new TableCell(new Paragraph(new Run(item.DishCount)));
                cellDishCount.ColumnSpan = 2;
                cellDishCount.TextAlignment = TextAlignment.Right;
                row.Cells.Add(cellDishCount);

                group.Rows.Add(row);
            }
            
        }
    }
}