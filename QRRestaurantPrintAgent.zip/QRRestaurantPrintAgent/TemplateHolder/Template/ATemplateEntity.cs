﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Windows.Documents;
using System.Windows.Markup;
using System.Windows.Threading;

namespace QRRestaurantPrintAgent.TemplateHolder.Template
{
    internal abstract class ATemplateEntity
    {

        public abstract string Path { get; }

        public abstract object TestData { get; }

        protected abstract void CustomRender(FlowDocument document, dynamic data);

        public FlowDocument LoadAsFlowDocument()
        {
            var currentAssembly = Assembly.GetExecutingAssembly();
            var resourceName = Path;
            {
                if (resourceName[0] != '/') resourceName = '/' + resourceName;
                resourceName = resourceName.Replace('/', '.');
                resourceName = new AssemblyName(currentAssembly.FullName).Name + resourceName;
            }
            if (currentAssembly.GetManifestResourceNames().Contains(resourceName))
            {
                try
                {
                    using (var resouce = currentAssembly.GetManifestResourceStream(resourceName))
                    {
                        return (FlowDocument)XamlReader.Load(resouce);
                    }
                }
                catch (Exception e)
                {
                    throw new Exception("Template load error: " + Path, e);
                }
            }
            else
            {
                throw new Exception("Template not found: " + Path);
            }
        }

        public FlowDocument BindingData(FlowDocument document, dynamic data)
        {
            document.DataContext = data;
            CustomRender(document, data);
            return document;
        }

    }

}