﻿using System;

namespace QRRestaurantPrintAgent.TemplateHolder
{
    public class TemplateLoaderException : ApplicationException
    {
        public TemplateLoaderException() : base() { }
        public TemplateLoaderException(string message) : base(message) { }
        public TemplateLoaderException(string message, Exception innerException) : base(message, innerException) { }
    }
}