﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace QRRestaurantPrintAgent.TemplateHolder
{

    public partial class TemplateViewer : Window
    {

        public string TemplateName { get; private set; }
        public TemplateViewer(string templateName)
        {
            InitializeComponent();
            this.TemplateName = templateName;
            Loaded += TemplateViewer_Loaded;
            PrinterDialog.Click += PrinterDialog_Click;
            Printer.Click += Printer_Click;
        }

        private void PrinterDialog_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new PrintDialog();
            if (dialog.ShowDialog() == true)
            {
                dialog.PrintVisual(Viewer, "TemplateViewer");
            }
        }

        private delegate void DoPrintMethod(PrintDialog dialog, DocumentPaginator paginator);

        private void Printer_Click(object sender, RoutedEventArgs e)
        {
            Dispatcher.BeginInvoke(new DoPrintMethod((dialog,paginator) =>
                {
                    dialog.PrintDocument(paginator, "TemplateViewer");
                }), DispatcherPriority.ApplicationIdle, new PrintDialog(), ((IDocumentPaginatorSource)TemplateLoader.LoadAndRenderAsFlowDocument("Demo", null)).DocumentPaginator);
            //dialog.PrintDocument(((IDocumentPaginatorSource)TemplateLoader.Test()).DocumentPaginator, "TemplateViewer");
        }

        private void TemplateViewer_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                Viewer.Document = TemplateLoader.LoadAndRenderAsFlowDocument("Demo",null);
            }
            catch (Exception ex)
            {
                {
                    Grid.UnregisterName("Viewer");
                    Grid.Children.Remove(Viewer);
                }
                {
                    var richTb = new RichTextBox();
                    richTb.AppendText(ex.ToString());
                    Grid.RegisterName("RichTb", richTb);
                    Grid.SetRow(richTb, 2);
                    Grid.Children.Add(richTb);
                    PrinterDialog.IsEnabled = false;
                    Printer.IsEnabled = false;
                }
            }
        }
    }
}