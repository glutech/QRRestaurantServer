﻿using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Linq;
using System.Printing;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;


namespace QRRestaurantPrintAgent.MainApplication
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {


        public MainWindow()
        {
            InitializeComponent();

            WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
            ResizeMode = System.Windows.ResizeMode.CanMinimize;

            InitializeTaskBar();

            InitializeTimer();

            Loaded += MainWindow_Loaded;
        }

        private void InitializeTaskBar()
        {
            TaskBar.Icon = Properties.Resources.printer;
            TaskBarShown.IsEnabled = false;

            TaskBarMinimized.Click += (sender, e) =>
                {
                    SetWindowHiden();
                };
            TaskBarShown.Click += (sender, e) =>
                {
                    SetWindowShown();
                };
            TaskBar.TrayMouseDoubleClick += (sender, e) =>
                {
                    if (Visibility != System.Windows.Visibility.Visible)
                    {
                        SetWindowShown();
                    }
                };
        }
        private Timer Timer;
        private void InitializeTimer()
        {
            Timer = new Timer(TimerCallback, null, 0, 5 * 1000);
        }

        private void TimerCallback(object state)
        {
            string name, description, comment, schema;
            name = description = comment = schema = "-";
            try
            {
                var defaultPrinterQueue = LocalPrintServer.GetDefaultPrintQueue();
                defaultPrinterQueue.Refresh();
                name = defaultPrinterQueue.Name;
                description = defaultPrinterQueue.Description;
                comment = defaultPrinterQueue.Comment;
                schema = defaultPrinterQueue.ClientPrintSchemaVersion.ToString();
            }
            catch { }
            Dispatcher.BeginInvoke((Action)delegate
            {
                PrinterName.Text = name;
                PrinterDescription.Text = description;
                PrinterComment.Text = comment;
                PrinterSchema.Text = schema;
            });
        }

        private void SetWindowShown()
        {
            Visibility = System.Windows.Visibility.Visible;
            Activate();
            TaskBarShown.IsEnabled = false;
            TaskBarMinimized.IsEnabled = true;
        }
        private void SetWindowHiden()
        {
            Visibility = System.Windows.Visibility.Hidden;
            TaskBarShown.IsEnabled = true;
            TaskBarMinimized.IsEnabled = false;
        }

        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            BtnMinimized.MouseLeftButtonDown += (S, E) =>
                {
                    SetWindowHiden();
                };

            this.HideSystemMenu();

            AgentDispatcher.Instance.Dispatcher = Dispatcher;
            WebSocketServer.Server.Instance.Start();

        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            // 阻止关闭程序，但可以通过杀进程的方法关闭
            e.Cancel = true;
        }


    }

    internal static class WindowExtends
    {


        #region HideSystemMenu

        private const int GWL_STYLE = -16;
        private const int WS_SYSMENU = 0x80000;
        [DllImport("user32.dll", SetLastError = true)]
        private static extern int GetWindowLong(IntPtr hWnd, int nIndex);
        [DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        public static void HideSystemMenu(this Window window)
        {
            var hwnd = new WindowInteropHelper(window).Handle;
            SetWindowLong(hwnd, GWL_STYLE, GetWindowLong(hwnd, GWL_STYLE) & ~WS_SYSMENU);
        }

        #endregion


        #region UnenableSystemMenuClose

        [DllImport("user32", CharSet = CharSet.Ansi, SetLastError = true, ExactSpelling = true)]
        private static extern int GetSystemMenu(int hwnd, int revert);
        [DllImport("user32", CharSet = CharSet.Ansi, SetLastError = true, ExactSpelling = true)]
        private static extern int EnableMenuItem(int menu, int ideEnableItem, int enable);


        private const int SC_CLOSE = 0xF060;
        private const int MF_BYCOMMAND = 0x00000000;
        private const int MF_GRAYED = 0x00000001;
        private const int MF_ENABLED = 0x00000002;

        public static void UnenableSystemMenuClose(this Window window)
        {
            var handle = new WindowInteropHelper(window).Handle.ToInt32();
            switch (EnableMenuItem(GetSystemMenu(handle, 0), SC_CLOSE, MF_BYCOMMAND | MF_GRAYED))
            {
                case MF_ENABLED:
                    break;
                case MF_GRAYED:
                    break;
                case -1:
                    throw new Exception("The Close menu item does not exist.");
                default:
                    break;
            }
        }

        #endregion

    }
}