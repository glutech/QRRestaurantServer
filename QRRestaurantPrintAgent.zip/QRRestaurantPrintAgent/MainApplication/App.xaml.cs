﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Windows;

namespace QRRestaurantPrintAgent.MainApplication
{
    /// <summary>
    /// App.xaml 的交互逻辑
    /// </summary>
    public partial class App : Application
    {
        
        private Mutex mutex;

        protected override void OnStartup(StartupEventArgs e)
        {
            bool createNew;
            mutex = new Mutex(true, Assembly.GetExecutingAssembly().FullName, out createNew);
            if (!createNew)
            {
                MessageBox.Show("程序已在运行中 请查看任务栏托盘");
                Application.Current.Shutdown();
            }
            else
            {
                base.OnStartup(e);
            }
        }
       
    }
}