﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading;


namespace QRRestaurantPrintAgent.MainApplication
{
    internal class AgentDispatcher
    {


        private static AgentDispatcher _instance;

        public static AgentDispatcher Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new AgentDispatcher();
                }
                return _instance;
            }
        }

        public System.Windows.Threading.Dispatcher Dispatcher { get; set; }

        private AgentDispatcher()
        {
            WebSocketServer.Server.Instance.SetOnRequestHandler(new WebSocketServer.Server.OnRequestHandler(DoServerReponse));
        }

        private WebSocketServer.ResponseAction DoServerReponse(string action, string data, WebSocketServer.Server.ParamHolder paramHolder)
        {
            switch (action)
            {
                case "print":
                    {
                        var waiter = new AutoResetEvent(false);
                        WebSocketServer.ResponseAction result = null;
                        try
                        {
                            var obj = JsonConvert.DeserializeAnonymousType<ExpandoObject>((string)data, new ExpandoObject());
                            //var template = paramHolder.HasParam("tpl") ? paramHolder.GetParam("tpl") : "Demo";
                            TemplateHolder.TemplateLoader.LoadAndRenderAsFlowDocumentOnDispatcher(Dispatcher, "Demo", obj, (document) =>
                                {
                                    PrintService.Printer.Print(Dispatcher, document, "小票打印", (printResult) =>
                                    {
                                        if (printResult)
                                        {
                                            result = new WebSocketServer.ResponseAction(WebSocketServer.ResponseAction.ActionEnum.Send, "ok");
                                        }
                                        else
                                        {
                                            result = new WebSocketServer.ResponseAction(WebSocketServer.ResponseAction.ActionEnum.Send, "error");
                                        }
                                        waiter.Set();
                                    });
                                });
                        }
                        catch (Exception e)
                        {
                            result = new WebSocketServer.ResponseAction(WebSocketServer.ResponseAction.ActionEnum.Send, e.Message);
                            waiter.Set();
                        }
                        waiter.WaitOne();
                        return result;
                    }
            }
            return new WebSocketServer.ResponseAction(WebSocketServer.ResponseAction.ActionEnum.Send, "非法请求");
        }

    }
}