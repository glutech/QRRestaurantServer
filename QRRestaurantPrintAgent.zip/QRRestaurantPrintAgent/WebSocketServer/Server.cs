﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using XSockets.Core.Common.Socket;
using XSockets.Core.XSocket;
using XSockets.Plugin.Framework;
using XSockets.Core.XSocket.Helpers;
using System.Threading;

namespace QRRestaurantPrintAgent.WebSocketServer
{
    public class Server
    {


        #region 单例模式

        private static Server _instance;

        public static Server Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Server();
                }
                return _instance;
            }
        }

        #endregion


        #region 类构造

        private Server()
        {
            _initServerContainer();
        }

        #endregion


        #region 服务器容器操作

        private IXSocketServerContainer _serverContainer;

        private void _initServerContainer()
        {
            // TODO: 多端口探测防止端口被使用
            _serverContainer = Composable.GetExport<IXSocketServerContainer>();
            _serverContainer.OnServersStarted += (sender, e) => { ServerStatus = ServerStatusEnum.Started; };
            _serverContainer.OnServersStopped += (sender, e) => { ServerStatus = ServerStatusEnum.Stoped; };
            _serverContainer.OnError += (sender, e) => { ServerStatus = ServerStatusEnum.InError; OnError(sender, e); };
            _serverContainer.OnServerClientConnection += (sender, e) => { Console.WriteLine("CONN"); };
            _serverContainer.OnServerClientDisconnection += (sender, e) => { Console.WriteLine("DISCONN"); };
        }

        public void Start()
        {
            _serverContainer.StartServers();
        }

        public void Stop()
        {
            _serverContainer.StopServers();
        }

        private void OnError(object sender, XSockets.Core.Common.Socket.Event.Arguments.OnErrorArgs e)
        {
            if (IsAutoRestart)
            {
                ThreadPool.QueueUserWorkItem((WaitCallback)delegate
                {
                    Thread.Sleep(1000);
                    Start();
                }, null);
            }
        }

        public enum ServerStatusEnum
        {
            Unknown,
            Started,
            Stoped,
            InError
        }

        public ServerStatusEnum ServerStatus { get; private set; }

        public bool IsAutoRestart { get; set; }
        #endregion


        #region 内部与控制器交互

        internal void NotifyOnRequest(XSocketController controller, string action, string data)
        {
            if (_onRequestHandler != null)
            {
                var r = _onRequestHandler(action, data, new ParamHolder(controller));
                if (r.Action != ResponseAction.ActionEnum.Ignore)
                {
                    if ((r.Action & ResponseAction.ActionEnum.Send) != 0)
                    {
                        controller.Send(r.Data, action);
                    }
                    if ((r.Action & ResponseAction.ActionEnum.Close) != 0)
                    {
                        controller.Close();
                    }
                }
            }
        }

        #endregion


        #region 外部通知委托

        public delegate ResponseAction OnRequestHandler(string action, string data, ParamHolder paramHolder);

        private OnRequestHandler _onRequestHandler;

        public void SetOnRequestHandler(OnRequestHandler handler)
        {
            _onRequestHandler = handler;
        }

        public void ClearOnRequestHandler()
        {
            _onRequestHandler = null;
        }

        public class ParamHolder
        {
            private XSocketController _controller;

            public ParamHolder(XSocketController controller)
            {
                this._controller = controller;
            }

            public bool HasParam(string name)
            {
                return _controller.HasParameterKey(name);
            }

            public string GetParam(string name)
            {
                return _controller.GetParameter(name);
            }
        }

        #endregion


    }
}
