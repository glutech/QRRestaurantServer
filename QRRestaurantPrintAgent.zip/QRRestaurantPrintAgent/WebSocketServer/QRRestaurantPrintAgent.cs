﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using XSockets.Core.XSocket;
using XSockets.Core.XSocket.Helpers;

namespace QRRestaurantPrintAgent.WebSocketServer
{
    public class QRRestaurantPrintAgent : XSocketController
    {
        public QRRestaurantPrintAgent()
        {
            this.OnOpen += (sender, e) => { };
            this.OnClose += (sender, e) => { };
        }

        public override void OnMessage(XSockets.Core.Common.Socket.Event.Interface.ITextArgs textArgs)
        {
            Server.Instance.NotifyOnRequest(this, textArgs.@event, textArgs.data);
        }

        public override void OnMessage(XSockets.Core.Common.Socket.Event.Interface.IBinaryArgs binaryArgs)
        {
            // LOG
        }
    }
}
