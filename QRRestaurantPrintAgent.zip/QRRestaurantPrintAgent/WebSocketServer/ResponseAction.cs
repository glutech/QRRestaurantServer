﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QRRestaurantPrintAgent.WebSocketServer
{
    public class ResponseAction
    {
        [Flags]
        public enum ActionEnum
        {
            Ignore = 0,
            Send = 1,
            Close = 2,
            SendAndClose = Send | Close
        }

        public ActionEnum Action { get; private set; }
        public object Data { get; private set; }

        public ResponseAction() : this(ActionEnum.Ignore) { }
        public ResponseAction(ActionEnum action) : this(action, null) { }
        public ResponseAction(ActionEnum action, object data)
        {
            this.Action = action;
            this.Data = data;
        }

        public static ResponseAction Ignore { get; private set; }
        public static ResponseAction Close { get; private set; }

        static ResponseAction()
        {
            Ignore = new ResponseAction();
            Close = new ResponseAction(ActionEnum.Close);
        }
    }
}
